package com.group27.bookstore;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/books")
public class BookController {
    
    @Autowired
    private BookRepository bookRepository;
    
    @GetMapping("/byGenre")
    public List<Book> getBooksByGenre(@RequestParam("genre") String genre) {
        return bookRepository.findByGenreName(genre);
    }
    
    @GetMapping("/topSellers")
    public List<Book> getTopSellers() {
        return bookRepository.findTop10ByOrderByNumSoldDesc();
    }
    
    @GetMapping("/byRating")
    public List<Book> getBooksByRating(@RequestParam("rating") Integer rating) {
        return bookRepository.findByRatingGreaterThanEqual(rating);
    }
    
    @PutMapping("/discountByPublisher")
    public void discountBooksByPublisher(@RequestParam("discountPercent") Integer discountPercent, @RequestParam("publisher") String publisherName) {
        bookRepository.discountBooksByPublisher(publisherName, discountPercent);
    }
}

/*
// HTTP GET request to retrieve list of books by genre
@RequestMapping(value = "/books", method = RequestMethod.GET)
public List<Book> getBooksByGenre(@RequestParam(value = "genre") String genre) {
   // Retrieve list of books from database using DAO layer
   List<Book> books = bookDao.getBooksByGenre(genre);
   return books;
}

// HTTP GET request to retrieve top sellers list
@RequestMapping(value = "/topsellers", method = RequestMethod.GET)
public List<Book> getTopSellers() {
   // Retrieve list of top sellers from database using DAO layer
   List<Book> books = bookDao.getTopSellers();
   return books;
}

// HTTP GET request to retrieve list of books by rating
@RequestMapping(value = "/books", method = RequestMethod.GET)
public List<Book> getBooksByRating(@RequestParam(value = "rating") int rating) {
   // Retrieve list of books from database using DAO layer
   List<Book> books = bookDao.getBooksByRating(rating);
   return books;
}

// HTTP PUT request to discount books by publisher
@RequestMapping(value = "/discount", method = RequestMethod.PUT)
public void discountBooksByPublisher(@RequestParam(value = "discount") int discountPercent, 
                                      @RequestParam(value = "publisher") String publisher) {
   // Update prices of books under the publisher in the database using DAO layer
   bookDao.discountBooksByPublisher(discountPercent, publisher);
}

 */